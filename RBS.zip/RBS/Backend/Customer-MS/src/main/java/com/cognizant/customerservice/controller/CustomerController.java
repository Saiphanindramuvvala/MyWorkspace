package com.cognizant.customerservice.controller;

import java.net.BindException;
import java.time.DateTimeException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

//import com.cognizant.authenticationservice.model.AppUser;
import com.cognizant.customerservice.feign.AuthorizationFeign;
import com.cognizant.customerservice.model.CustomerEntity;
import com.cognizant.customerservice.model.MessageDetails;
import com.cognizant.customerservice.repository.CustomerRepository;
import com.cognizant.customerservice.service.CustomerService;

import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin()
@Slf4j
public class CustomerController {
	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private MessageDetails messageDetails;
	
	@Autowired
	AuthorizationFeign authorizationFeign;
	
	@GetMapping("/health")
	public ResponseEntity<String> healthCheckup() {
		log.info("Health Check for Customer Microservice");
		log.info("health checkup ----->{}", "fine or not");
		return new ResponseEntity<>("customer health is fine", HttpStatus.OK);
	}
	@PostMapping("/createcustomer")
	public ResponseEntity<?> createCustomer(@RequestHeader("Authorization") String token,
			@Valid @RequestBody CustomerEntity customer) {
		customerService.hasEmployeePermission(token);
		CustomerEntity customerEntity = customerService.createCustomer(token, customer);
		if (customerEntity != null)
			return new ResponseEntity<CustomerEntity>(customerEntity, HttpStatus.CREATED);
		else
			return new ResponseEntity<>("Customer Creation is UNSUCCESSFUL", HttpStatus.NOT_ACCEPTABLE);
	}
	
	@GetMapping("/getcustomerdetails/{id}")
	public ResponseEntity<?> getCustomerDetails(@RequestHeader("Authorization") String token, @PathVariable String id) {
		customerService.hasEmployeePermission(token);
		CustomerEntity toReturnCustomerDetails = customerService.getCustomerDetail(token, id);
		if (toReturnCustomerDetails == null)
			return new ResponseEntity<>("Customer Userid " + id + " DOES NOT EXISTS", HttpStatus.NOT_ACCEPTABLE);
		toReturnCustomerDetails.setPassword(null);
		return new ResponseEntity<>(toReturnCustomerDetails, HttpStatus.OK);
	}
	
	
	@GetMapping("/check")
	public String checkAccessWWithoutValidation(@RequestHeader("Authorization") String token) {
		customerService.hasEmployeePermission(token);
		return "Your Token is valid";
	}
	@GetMapping("/find")
	public ResponseEntity<List<CustomerEntity>> findUsers(@RequestHeader("Authorization") final String token) {
		customerService.hasEmployeePermission(token);
		List<CustomerEntity> allCust = new ArrayList<>();
		List<CustomerEntity> findAll =(List<CustomerEntity>) customerRepository.findAll();
		findAll.forEach(emp -> allCust.add(emp));
		System.out.println(allCust);
		return new ResponseEntity<>(allCust, HttpStatus.CREATED);
	}
}
