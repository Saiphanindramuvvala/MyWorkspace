INSERT INTO ACCOUNT(account_Id,customer_Id,current_Balance,account_Type,opening_date,owner_Name)
VALUES (1000000001,'CUSTOMER101',80000.00, 'Savings',TO_DATE('09/10/2021', 'DD/MM/YYYY'), 'Harish');

INSERT INTO ACCOUNT(account_Id,customer_Id,current_Balance,account_Type,opening_date,owner_Name)
VALUES (1000000002, 'CUSTOMER102', 2000.00, 'Current', TO_DATE('09/10/2021', 'DD/MM/YYYY'),'Vimal');