package com.cognizant.transactionservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.transactionservice.models.TransactionInput;
import com.cognizant.transactionservice.models.Account;

@FeignClient(name = "account-ms", url = "${feign.url-account-service}")
public interface AccountFeign {

	@GetMapping("/getaccountby/{accountId}")
	public Account getAccount(@RequestHeader("Authorization") String token,
			@PathVariable(name = "accountId") long accountId);

	@PostMapping("/updateaccount")
	public boolean updateAccount(Account sourceAccount);

	@GetMapping("/updateaccountbyid/{id}")
	public boolean updateAccountById(@PathVariable("id") long accId, double currentBalance);
	
	@PostMapping("/transaction")
	public ResponseEntity<?> transaction(@RequestHeader("Authorization") String token, @RequestBody TransactionInput transInput);

}
