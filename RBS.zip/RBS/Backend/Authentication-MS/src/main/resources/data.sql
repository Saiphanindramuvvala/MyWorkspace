insert into appuser (userid,username,password,role) values ('EMPLOYEE101','employee','employee','EMPLOYEE');
insert into appuser (userid,username,password,role) values ('CUSTOMER101','customer','customer','CUSTOMER');
insert into appuser (userid,username,password,role) values ('CUSTOMER102','customer','customer','CUSTOMER');
