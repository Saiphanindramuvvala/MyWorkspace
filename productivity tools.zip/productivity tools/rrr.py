a = 25
b = 50
print("Sum",a+b,"\n","Difference",a-b,"\n","Product",a*b,"\n","Division",a/b,"\n","Module",a%b,"\n","Expo",a**b,"\n","Floor Division",a//b)
