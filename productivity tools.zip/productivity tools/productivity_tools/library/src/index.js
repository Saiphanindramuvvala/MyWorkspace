import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import Main from "./Main.js";

var destination = document.querySelector("#app");

ReactDOM.render(<Main />, destination);
